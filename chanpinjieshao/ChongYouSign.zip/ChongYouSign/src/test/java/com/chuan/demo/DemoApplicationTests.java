package com.chuan.demo;

import com.chuan.demo.AllException.LoginException;
import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DemoApplicationTests {

    @Test
    void contextLoads() throws LoginException {


    }

}
